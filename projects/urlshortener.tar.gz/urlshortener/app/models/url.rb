class Url < ActiveRecord::Base
end
